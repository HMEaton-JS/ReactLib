export { default as ScoreCard } from './ScoreCard/ScoreCard';

